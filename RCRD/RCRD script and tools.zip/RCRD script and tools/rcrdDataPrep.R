
#### RCRD DATA CLEANING SCRIPT 
# Created by Martina Slapkova, OCtober 2021

## Data downloaded from here: https://www.cancerdata.nhs.uk/covid-19/rcrd
## Demographic factors > Downloads > second link ("Download time trend data for all cancer groups and demographic factors")

#------------ 1. LOAD LIBRARIES --------------

library(tidyverse)
library(zoo)
library(stats)
library(readxl)

#----------- 2. LOAD DATA ------------------

#The datasets should be changed to the latest two, where 'rcrd_data' is the latest dataset available and 'raw_old' the one before

rcrd_data <- read_csv("C:/RProjects/myrepo/RCRD/October 2021/Incidence_Treatment_statistics_England_Oct21.csv")

wd <- read_excel("C:/RProjects/myrepo/RCRD/October 2021/WorkingDays.xlsx")

raw_new <- rcrd_data %>% 
  mutate(data_type = "new") %>% 
  filter(Metric == "New cancer diagnoses (observed)") %>%
  rename(new = Statistic) %>%
  select(-data_type, -"Date", - "Data completeness")

raw_old <- read_csv("C:/RProjects/myrepo/RCRD/October 2021/Incidence_Treatment_statistics_England_Sep21.csv") %>% 
  mutate(data_type = "old") %>% 
  filter(Metric == "New cancer diagnoses (observed)") %>% 
  rename(old = Statistic) %>% 
  select(-data_type,-"Date", - "Data completeness")


# ------------- 3. CREATE A FLAT FILE FOR COMPLETENESS ANALYSIS TOOL  --------------

data <- left_join(raw_new, raw_old)

rm(raw_new,raw_old)

data$Date <- as.yearmon(paste(data$Month, data$Year, sep = " "))

data <- data %>% 
  select(Date, `Cancer group`:old) %>%
  filter(Date >= "Jan 2019")

rcrd_demo_data <- data %>% 
  mutate(
    ndiff_newOld = new - old,
    propchange_newOld = round(ndiff_newOld/old,2)) %>%
  filter(Breakdown %in% c("Route to Diagnosis", "Stage at diagnosis"))

write.csv(rcrd_demo_data, "rcrdCompletnessData.csv") 

# ------------- 4. CREATE A FLAT FILE FOR RCRD SPREADSHEET  --------------

rcrd_data$Date <- as.yearmon(paste(rcrd_data$Month, rcrd_data$Year, sep = " "))
wd$Date <- as.yearmon(paste(wd$Month, wd$Year, sep = " "))

rcrd_data <- rcrd_data %>% 
  filter(Metric == "New cancer diagnoses (observed)", 
         Breakdown %in% c("Route to Diagnosis", "Stage at diagnosis"), 
         Year != "2018") %>% 
  select(- "Data completeness", -"Metric")

stage <- rcrd_data %>% 
  filter(Breakdown == "Stage at diagnosis", 
         `Cancer group` != "Other malignant neoplasms") %>%
  select(-"Breakdown") 

stage2019 <- stage %>%
  filter(Year == "2019") %>%
  select(-"Year", - "Date") %>%
  rename(Stat2019 = "Statistic")

stage <- left_join(stage, stage2019, by = c("Month", "Cancer group", "Demographic"), keep = FALSE)

stageCalcs <- left_join(stage, wd, by = "Date", keep = FALSE) %>%
  mutate(Statistic2019WdAdj = Stat2019*wd2019AdjRatio, 
         nDiff = Statistic - Statistic2019WdAdj, 
         propChange = nDiff / Statistic2019WdAdj) %>%
  select(Date:Statistic, Statistic2019WdAdj, nDiff, propChange)

stageCalcs$Breakdown <- "Stage at diagnosis"

route <- rcrd_data %>% 
  filter(Breakdown == "Route to Diagnosis", 
         `Cancer group` != "Other malignant neoplasms") %>%
  select(-"Breakdown") 

route2019 <- route %>%
  filter(Year == "2019") %>%
  select(-"Year", - "Date") %>%
  rename(Stat2019 = "Statistic")

route <- left_join(route, route2019, by = c("Month", "Cancer group", "Demographic"), keep = FALSE)

routeCalcs <- left_join(route, wd, by = "Date", keep = FALSE) %>%
  mutate(Statistic2019WdAdj = Stat2019*wd2019AdjRatio, 
         nDiff = Statistic - Statistic2019WdAdj, 
         propChange = nDiff / Statistic2019WdAdj) %>%
  select(Date:Statistic, Statistic2019WdAdj, nDiff, propChange)

routeCalcs$Breakdown <- "Route to Diagnosis"

rcrd_clean <- rbind(routeCalcs, stageCalcs)

write.csv(rcrd_clean, "rcrdRawData.csv")
